import 'dart:io';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:x_tracker_map/cubit/home_cubit/home_cubit.dart';
import 'package:x_tracker_map/modules/home_screen.dart';
import 'package:x_tracker_map/shared/constants.dart';
import 'package:x_tracker_map/shared/themes.dart';
import 'cubit/bloc_observer.dart';
import 'network/local/cache_helper.dart';
import 'network/remote/dio_helper.dart';

main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (defaultTargetPlatform == TargetPlatform.android) {
    AndroidGoogleMapsFlutter.useAndroidViewSurface = true;
  }
  DioHelper.init();
  await Firebase.initializeApp();
  await CacheHelper.init();
  Future<String?> getId() async {
    var deviceInfo = DeviceInfoPlugin();
    if (Platform.isAndroid) {
      var androidDeviceInfo = await deviceInfo.androidInfo;
      return androidDeviceInfo.id ?? '';
    }
    return null;
  }

  FirebaseMessaging messaging = FirebaseMessaging.instance;
  String? token = await messaging.getToken();

  String? id = await getId();

  await CacheHelper.saveData(key: 'deviceId', value: id);
  await CacheHelper.saveData(key: 'deviceToken', value: token);
  print('device id is $deviceId');
  print('device token is $deviceToken');

  BlocOverrides.runZoned(
    () {
      runApp(
        const MyApp(),
      );
    },
    blocObserver: MyBlocObserver(),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => HomeCubit(),
        ),
      ],
      child: MaterialApp(
        theme: lightTheme,
        debugShowCheckedModeBanner: false,
        // home: const SplashScreen(),
        home: HomeScreen(),
      ),
    );
  }
}

//DE:8C:6A:25:23:16:7E:F2:20:DD:F2:65:01:65:04:16:FA:95:D1:3C
