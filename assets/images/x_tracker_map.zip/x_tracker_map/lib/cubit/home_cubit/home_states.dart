import '../../models/logout_model.dart';

abstract class HomeStates{}

class HomeInitialState extends HomeStates{}


class UserLogOutLoadingState extends HomeStates{}

class UserLogOutSuccessState extends HomeStates {

  final LogOutModel logOutModel;

  UserLogOutSuccessState(this.logOutModel);

}

class UserLogOutErrorState extends HomeStates {}

class ChangeUserStatusState extends HomeStates{}
