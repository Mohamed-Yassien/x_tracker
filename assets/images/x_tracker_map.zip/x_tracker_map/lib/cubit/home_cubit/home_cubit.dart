import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:x_tracker_map/cubit/home_cubit/home_states.dart';

import '../../models/logout_model.dart';
import '../../network/endpoints.dart';
import '../../network/remote/dio_helper.dart';
import '../../shared/constants.dart';

class HomeCubit extends Cubit<HomeStates> {
  HomeCubit() : super(HomeInitialState());

  static HomeCubit get(context) => BlocProvider.of(context);

  LogOutModel? logOutModel;

  void userLogOut() {
    emit(UserLogOutLoadingState());
    DioHelper.postData(url: LOGOUT, data: {
      'id': userId,
    }).then((value) {
      logOutModel = LogOutModel.fromJson(value.data);
      print(logOutModel!.message);
      emit(UserLogOutSuccessState(logOutModel!));
    }).catchError((error) {
      print(error.toString());
      emit(UserLogOutErrorState());
    });
  }




  bool isOffline = true;
  String buttonText = 'Start';
  String statusText = 'offline';
  String alertContent = 'Start Sending Your Location';
  Color statusTextColor = Colors.red;

  void changeUserStatus() {
    isOffline = !isOffline;
    buttonText = isOffline ? 'Start' : 'Stop';
    alertContent = isOffline
        ? 'Start Sending Your Location'
        : 'Stop Sending Your Location';
    statusTextColor = isOffline ? Colors.red : Colors.green;
    statusText = isOffline ? 'offline' : 'online';
    emit(ChangeUserStatusState());
  }


  Completer<GoogleMapController> mController = Completer();

   CameraPosition kGooglePlex = const CameraPosition(
    target: LatLng(
      37.42796133580664,
      -122.085749655962,
    ),
    zoom: 14.4746,
  );

   CameraPosition kLake = const CameraPosition(
    bearing: 192.8334901395799,
    target: LatLng(37.43296265331129, -122.08832357078792),
    tilt: 59.440717697143555,
    zoom: 19.151926040649414,
  );

  Future<void> goToTheLake() async {
    final GoogleMapController controller = await mController.future;
    controller.animateCamera(CameraUpdate.newCameraPosition(kLake));
  }
}
