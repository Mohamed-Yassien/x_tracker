import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:x_tracker_map/cubit/login_cubit/login_states.dart';
import 'package:x_tracker_map/models/login_model.dart';
import 'package:x_tracker_map/models/logout_model.dart';
import 'package:x_tracker_map/network/remote/dio_helper.dart';
import 'package:x_tracker_map/shared/constants.dart';
import 'package:x_tracker_map/shared/widgets/reusable_toast.dart';

import '../../network/endpoints.dart';

class LoginCubit extends Cubit<LoginStates> {
  LoginCubit() : super(LoginInitialState());

  static LoginCubit get(context) => BlocProvider.of(context);

  bool isPassword = true;

  IconData iconData = Icons.visibility_off;

  void changePasswordVisibility() {
    isPassword = !isPassword;
    iconData = isPassword ? Icons.visibility_off : Icons.visibility;
    emit(LoginChangePasswordVisibilityState());
  }

  LoginModel? loginModel;

  void userLogin({
    required String phone,
    required String pin,
  }) {
    emit(LoginUserLoadingState());
    DioHelper.postData(url: LOGIN, data: {
      'mobile_no': phone,
      'pin': pin,
      'deviceid': deviceId,
      'devicetoken': deviceToken,
      'devicetype': 'a',
    }).then((value) {
      loginModel = LoginModel.fromJson(value.data);
      print(loginModel!.message);
      emit(LoginUserSuccessState(loginModel!));
    }).catchError((error) {
      print(error.toString());
      emit(LoginUserErrorState());
    });
  }




}
