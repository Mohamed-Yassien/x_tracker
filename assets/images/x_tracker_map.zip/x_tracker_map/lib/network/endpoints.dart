var LOGIN = 'login';
var LOGOUT = 'logout';
