package com.example.x_tracker_map

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
